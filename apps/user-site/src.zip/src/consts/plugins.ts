export const plugins = {
  ai: "AI Grading",
  "test-runner": "Test Runner",
  "static-analysis": "Static Analysis",
  None: "Manual Grading",
} as const;
